Copyright (C) 2014-2022 Advanced Micro Devices, Inc. All Rights Reserved.

Redistribution and use of this software in unmodified binary form only are
permitted provided that the following conditions are met:

    1) Redistributions must reproduce the above copyright notice and this
    license in the documentation and/or other materials provided with the
    distribution.

    2) No reverse engineering, decompilation, or disassembly of this software
    is permitted (unless to the extent explicitly permitted by law).

    3) Neither the name of the copyright holder nor the names of its
    contributors may be used to endorse or promote products derived from this
    software without specific prior written permission.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
